﻿public static class Roles
{
    public const string? ROLE_ACESSO_APIS = "Acesso-APIs";
}

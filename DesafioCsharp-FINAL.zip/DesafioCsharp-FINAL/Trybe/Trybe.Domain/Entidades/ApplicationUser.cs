﻿using Microsoft.AspNetCore.Identity;

namespace Trybe.Domain.Entidades
{
    public class ApplicationUser : IdentityUser
    {
    }
}

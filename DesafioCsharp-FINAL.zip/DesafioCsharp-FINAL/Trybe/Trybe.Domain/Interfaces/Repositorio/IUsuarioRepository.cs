﻿using Trybe.Domain.Entidades;

namespace Trybe.Domain.Interfaces.Repositorio
{
    public interface IUsuarioRepository : IBaseRepository<Usuario>
    {}
}
